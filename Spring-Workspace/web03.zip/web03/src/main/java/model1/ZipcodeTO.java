package model1;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ZipcodeTO {
	private String zipcode;
	private String sido;
	private String gugun;
	private String dong;
	private String ri; 
	private String bunji;
}
